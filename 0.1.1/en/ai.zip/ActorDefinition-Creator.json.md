# PH Core Creator - JSON Representation - Draft PH Core Implementation Guide v0.1.1

## : PH Core Creator

[Raw json](ActorDefinition-Creator.json) | [Download](ActorDefinition-Creator.json)

